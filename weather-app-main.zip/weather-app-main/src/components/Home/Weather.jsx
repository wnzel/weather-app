import React, { useState, useEffect } from "react";

import { useQuery } from "@tanstack/react-query";

const Weather = ({ city, degree }) => {
  const dayNames = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
  ];

  function getDayName(dateString) {
    // Parse the date string and create a Date object
    const dateParts = dateString.split("-");
    const year = parseInt(dateParts[0]);
    const month = parseInt(dateParts[1]) - 1;
    const day = parseInt(dateParts[2]);

    const date = new Date(Date.UTC(year, month, day));

    const dayNumber = date.getUTCDay();

    const dayName = dayNames[dayNumber];

    return dayName;
  }

  const getSrc = (data) => {
    if (!data.current.is_day) {
      return `src/assets/night/${data.current.condition.text}.svg`;
    }
    return `src/assets/day/${data.current.condition.text}.svg`;
  };

  const forecastIcon = (data) => {
    return `src/assets/day/${data.day.condition.text}.svg`;
  };

  const token = import.meta.env.VITE_WEATHER_TOKEN;
  const { isLoading, error, data } = useQuery({
    queryKey: ["current"],
    queryFn: () => {
      return fetch(
        `http://api.weatherapi.com/v1/forecast.json?key=${token}&q=${city}&days=4`
      ).then((res) => res.json());
    },
  });

  if (isLoading)
    return (
      <span className="text-9xl flex justify-center items-center flex-1">
        . . .
      </span>
    );
  if (error) return <span>Error: {error.message}</span>;
  if (!data) return <span>No data</span>;

  return (
    <>
      <div className=" flex-1 flex md:flex-row flex-col h-1/2 md:self-center md:items-stretch items-center">
        <div
          id="current-container"
          className="flex flex-col md:w-1/3 w-full justify-start items-center gap-12"
        >
          <div className="flex shrink flex-col justify-center items-center gap-2 ">
            <h1 className=" md:text-6xl text-5xl font-medium md:font-bold ">
              {data.location.name}
            </h1>
            <div className="flex gap-4 md:text-lg text-sm">
              <h2>
                H:{" "}
                {degree
                  ? Math.round(data.forecast.forecastday[0].day.maxtemp_c)
                  : Math.round(data.forecast.forecastday[0].day.maxtemp_f)}
                °
              </h2>
              <h2>
                L:{" "}
                {degree
                  ? Math.round(data.forecast.forecastday[0].day.mintemp_c)
                  : Math.round(data.forecast.forecastday[0].day.mintemp_f)}
                °
              </h2>
            </div>
          </div>

          <div className="flex flex-col justify-center items-center">
            <img
              src={getSrc(data)}
              className="md:w-40 md:h-40 w-24 h-24"
              alt=""
            />
            <h2 className="md:text-xl md:font-medium text-sm">
              {data.current.condition.text}
            </h2>
            <h1 className="md:text-7xl md:font-bold text-4xl font-medium">
              {degree
                ? Math.round(data.current.temp_c)
                : Math.round(data.current.temp_f)}
              °
            </h1>
          </div>
        </div>

        <div
          id="forecast-container"
          className="flex flex-col items-center justify-start w-2/3"
        >
          <h1 className="md:text-6xl text-4xl md:font-semibold font-medium md:mt-0 mt-8">
            3-Day Forecast
          </h1>

          <div className="flex md:gap-20 gap-6 md:my-auto my-10 md:flex-row flex-col">
            {data.forecast.forecastday.map((days) => (
              <>
                <div className="flex flex-col justify-start items-center gap-1">
                  <h1 className="md:text-3xl md:font-medium text-2xl font-normal">
                    {getDayName(days.date)}
                  </h1>
                  <img src={forecastIcon(days)} className="h-10 w-10" alt="" />
                  <h2 className=" font-extralight">
                    {days.day.condition.text}
                  </h2>

                  <div className="flex gap-2">
                    <h2>
                      H:{" "}
                      {degree
                        ? Math.round(days.day.maxtemp_c)
                        : Math.round(days.day.maxtemp_f)}
                      °
                    </h2>
                    <h2>
                      L:{" "}
                      {degree
                        ? Math.round(days.day.mintemp_c)
                        : Math.round(days.day.mintemp_f)}
                      °
                    </h2>
                  </div>
                  <h2>Humidity: {days.day.avghumidity}%</h2>
                  {days.day.daily_will_it_rain ? (
                    <h1 className=" text-blue-500 font-medium flex items-center gap-1">
                      <img src="src/assets/day/mist.svg" alt="" />{" "}
                      <p>{days.day.daily_chance_of_rain}%</p>
                    </h1>
                  ) : (
                    <></>
                  )}
                  {days.day.daily_will_it_snow ? (
                    <h1 className=" text-blue-200 font-medium flex items-center gap-1">
                      <img src="src/assets/day/blizzard.svg" alt="" />
                      <p>{days.day.daily_chance_of_snow}%</p>
                    </h1>
                  ) : (
                    <></>
                  )}

                  {/* <p>{days.day.condition.text}</p> */}
                </div>
              </>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default Weather;
