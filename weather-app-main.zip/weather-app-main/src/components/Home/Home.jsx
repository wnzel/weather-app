import React, { useState } from "react";

import Weather from "./Weather";

const Home = () => {
  const [current, setCurrent] = useState("");
  const [city, setCity] = useState("");
  const [degrees, setDegrees] = useState(false);

  const handleCityChange = (event) => {
    setCurrent(event.target.value);
  };

  const handleCheckbox = (event) => {
    setDegrees(event.target.checked);
    // console.log(event.target.checked);
  };

  const handleEnter = (event) => {
    if (event.key === "Enter") {
      handleSearch();
    }
  };

  const handleSearch = () => {
    setCity(current);
    setCurrent("");
  };

  return (
    <>
      <div className="container mx-auto md:h-screen flex flex-col md:flex-row">
        <div className="p-4 flex flex-col justify-center items-center gap-6 md:gap-12 ">
          <input
            id="city-search"
            type="text"
            placeholder="Search city"
            className="p-6 border border-black rounded-2xl"
            value={current}
            onChange={handleCityChange}
            onKeyDown={handleEnter}
          />
          <button
            onClick={handleSearch}
            className=" bg-black px-8 py-2 rounded-lg text-white duration-500 hover:bg-green-500 transition-colors hidden md:block"
          >
            Search
          </button>

          {/* <h1>Live City: {current}</h1>
          <h1>City: {city}</h1> */}
          <input
            type="checkbox"
            id="tempCheck"
            onChange={handleCheckbox}
            className="peer hidden "
          />
          <label
            htmlFor="tempCheck"
            className="hover:underline peer-checked:text-green-500"
          >
            Celsius
          </label>
        </div>

        {city ? <Weather key={city} city={city} degree={degrees} /> : <></>}
      </div>
    </>
  );
};

export default Home;
